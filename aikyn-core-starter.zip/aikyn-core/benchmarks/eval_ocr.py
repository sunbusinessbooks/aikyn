# eval ocr stub
