# ocr stub
